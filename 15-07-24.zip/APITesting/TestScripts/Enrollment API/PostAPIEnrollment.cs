﻿using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollment
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentTest test;
        private ExtentReports extent;

        [OneTimeSetUp]
        public void SetupReporting()
        {
            var htmlReporter = new ExtentHtmlReporter("C:\\Users\\Reports\\extent.html");
            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
        }


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void PostAPIEnrollmentEndPoint()
        {
            test = extent.CreateTest("PostEnrollmentAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.postAPIEnrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");
                // Add JSON body to the request
                request.AddJsonBody(new
                {
                    //ClientId = randomGuidString,
                    displayName = "aadapp-ccm-platform-api-client-nonprod",
                    costCenter = "99999",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        allowedFromEmails = new[]
                        {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                    },
                    requireSms = false
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeCreated(response);
                test.Log(Status.Pass, "PostEnrollmentAPI-Request Executed and Response validated succesfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test]
        public void WrongClientID()
        {
           test = extent.CreateTest("PostEnrollmentAPI-wrongclientID").Info("Test Started");
            try
            {
                client = new RestClient(constants.postAPIEnrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");


                request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");
                // Add JSON body to the request
                request.AddJsonBody(new
                {
                    ClientId = "51ab2cc5-cad-4572-97978f",
                    displayName = "aadapp-ccm-platform-api-client-nonprod",
                    costCenter = "99999",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        allowedFromEmails = new[]
                        {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                    },
                    requireSms = false
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeBadRequest(response);
                test.Log(Status.Pass, "PostEnrollmentAPI-wrongclientID Request Executed and Response validated succesfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        
    }

        [Test]
        public void RemoveMandatoryFields()
        {
            test = extent.CreateTest("PostEnrollmentAPI-RemoveMandatoryFields").Info("Test Started");
            try
            {
            client = new RestClient(constants.postAPIEnrollmentURL);
            test.Log(Status.Pass, "Created a RestClient Object");

            request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
            test.Log(Status.Pass, "Created a RestRequest Object");

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            test.Log(Status.Pass, "Bearer Token added");

            request.AddHeader("ActionedBy", "Test");

            request.AddJsonBody(new
            {
                ClientId = "51ab2cc5-cad-4572-97978f",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            response = client.Execute(request);
            helper.HandleResponseStatusCodeBadRequest(response);
            test.Log(Status.Pass, "PostEnrollmentAPI-RemoveMandatoryFields Request Executed and Response validated succesfully");
        }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test]
        public void MissingActionByField()
        {
            test = extent.CreateTest("PostEnrollmentAPI-MissingActionByField").Info("Test Started");
            try
            {
            client = new RestClient(constants.postAPIEnrollmentURL);
            test.Log(Status.Pass, "Created a RestClient Object");

            request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
            test.Log(Status.Pass, "Created a RestRequest Object");

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            test.Log(Status.Pass, "Bearer Token added");

            request.AddJsonBody(new
            {
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "99999",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            response = client.Execute(request);
            helper.HandleResponseStatusCodeBadRequest(response);
            test.Log(Status.Pass, "PostEnrollmentAPI-MissingActionByField Request Executed and got the Response validated successfully");
        }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }


        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
        [OneTimeTearDown]

        public void TearDownReporting()
        {
            extent.Flush();

        }
    }
}
