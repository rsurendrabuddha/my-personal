﻿using System.ComponentModel;
using APITesting.Config;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class GetAPIEnrollment 
    {
        private string bearerToken;
        private RestClient client ;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void GetMethodAPIEnrollment()
        {
            client = new RestClient(constants.enrollmentURL);
            request = new RestRequest(constants.apiEnrollmentEndpoint, Method.Get);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
    }
}


