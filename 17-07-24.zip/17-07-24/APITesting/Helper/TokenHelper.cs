﻿using System;
using APITesting.TestScripts;
using Esprima;
using Newtonsoft.Json.Linq;

namespace APITesting
{
    public class TokenHelper
    {
        private string _bearerToken;

        public string GetToken(string tokenType)
        {
            var tokenRetriever = new TokenRetrieval();
            switch (tokenType)
            {
                case "Enrollment":
                    
                    _bearerToken = tokenRetriever.GetBearerTokenForEnrollment().GetAwaiter().GetResult();
                    return _bearerToken;

                case "Query":
                    
                    _bearerToken = tokenRetriever.GetBearerTokenForQueryAPI().GetAwaiter().GetResult();
                     return _bearerToken;

                default:
                    throw new ArgumentException("Unsupported token type");
            }


        }
    }
}
