﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APITesting.Config;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollment
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void PostAPIEnrollmentEndPoint()
        {
            client = new RestClient(constants.postAPIEnrollmentURL);
            request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            // Add JSON body to the request
            request.AddJsonBody(new
            {
                //ClientId = randomGuidString,
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "99999",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [Test]
        public void WrongClientID()
        {
            client = new RestClient(constants.postAPIEnrollmentURL);
            request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            // Add JSON body to the request
            request.AddJsonBody(new
            {
                ClientId = "51ab2cc5-cad-4572-97978f",
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "99999",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [Test]
        public void RemoveMandatoryFields()
        {
            client = new RestClient(constants.postAPIEnrollmentURL);
            request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            request.AddJsonBody(new
            {
                ClientId = "51ab2cc5-cad-4572-97978f",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [Test]
        public void InvalidJsonFormat()
        {
            client = new RestClient(constants.postAPIEnrollmentURL);
            request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            request.AddJsonBody(new
            {
                ClientId = "51ab2cc5-cad-4572-97978f",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new
                {
                    new()
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }


        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
    }
}
