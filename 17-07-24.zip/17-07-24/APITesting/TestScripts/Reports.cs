﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports;
using NUnit.Framework;
using APITesting;
using RestSharp;
using System.ComponentModel;
using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;

namespace CMA.TestScripts
{
    public class Reports
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentReports extent;
        private ExtentTest test;

        [OneTimeSetUp]
        public void ExtentGenerationReports()
        {
            string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string actualPath = pth.Substring(0, pth.LastIndexOf("bin"));
            String projectpth = new Uri(actualPath).LocalPath;


            string reportPath = "C:\\Users\\Reports\\extent.txt";
            extent = new ExtentReports();

            var htmlReporter = new ExtentHtmlReporter(reportPath);
            extent.AttachReporter(htmlReporter);
        }
        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken("Enrollment");
            Console.WriteLine("Token obtained: " + bearerToken);
        }
        //[Test]
        //public void GetMethodAPIEnrollment()
        //{
        //    test = extent.CreateTest("Test").Info("Test Started");
        //    test.Log(Status.Pass, "Search submitted");
        //    client = new RestClient(constants.getenrollmentURL);
        //    request = new RestRequest(constants.getapiEnrollmentEndpoint, Method.Get);
        //    request.AddHeader("Authorization", $"Bearer {bearerToken}");
        //    response = client.Execute(request);
        //    helper.HandleResponseStatusCodeOk(response);
        //}
        [TearDown]
        public void TearDown()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stackTrace = "<pre>" + TestContext.CurrentContext.Result.StackTrace + "</pre>";
            var errorMessage = TestContext.CurrentContext.Result.Message;
        }

        [OneTimeTearDown]
        public void EndReport()
        {
            //  extent.Flush();

        }

    }
}
