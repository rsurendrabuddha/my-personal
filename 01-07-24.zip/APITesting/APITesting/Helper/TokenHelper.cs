﻿using System;
using APITesting.TestScripts;

namespace APITesting
{
    public class TokenHelper
    {
        private string _bearerToken;

        public string GetToken()
        {
            if (string.IsNullOrEmpty(_bearerToken))
            {
                // Retrieve the token if it's not already cached
                var tokenRetriever = new TokenRetrieval();
                _bearerToken = tokenRetriever.GetBearerToken().GetAwaiter().GetResult(); // Ensure synchronous call
            }
            else
            {
                // Implement token refresh logic if needed
                // Example: Check token expiry and refresh if necessary
            }

            return _bearerToken;
        }
    }
}
