﻿using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollmentSearch : ExtentReportSetup
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
      
        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
             //test = extent.CreateTest(TestContext.CurrentContext.Test.Name);
            test = CreateTest("test PostAPIEnrollmentSearch");
        }

        [Test]
        public void PostAPIEnrollmentSearchEndPoint()
        {
            //test = extent.CreateTest("PostEnrollmentSearchAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.postApiEnrollmentSearchURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");
                request.AddJsonBody(new
                {
                    clientIdList = new[] { "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f" }
                });

                response = client.Execute(request);
                helper.HandleResponseStatusCodeOk(response);
                test.Log(Status.Pass, "PostEnrollmentSearchAPI-Request Executed and Response validated succesfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }
            [Test]
        public void WrongClientID()
        {
            
            try
            {
             client = new RestClient(constants.postApiEnrollmentSearchURL);
            test.Log(Status.Pass, "Created a RestClient Object");

            request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
            test.Log(Status.Pass, "Created a RestRequest Object");

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            test.Log(Status.Pass, "Bearer Token added");

            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "51ab2ddc5-ca6d-4572-9bb8-9a4624f7978f" }
            });

            response = client.Execute(request);
            helper.HandleResponseStatusCodeOk(response);
            test.Log(Status.Pass, "PostEnrollmentSearchAPIwrongclientID-Request Executed and Response validated succesfully");
        }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test]
        public void NoClientID()
        {
            
            try
            {
             client = new RestClient(constants.postApiEnrollmentSearchURL);
            test.Log(Status.Pass, "Created a RestClient Object");

            request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
            test.Log(Status.Pass, "Created a RestRequest Object");

            
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            test.Log(Status.Pass, "Bearer Token added");

            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "" }
            });
            response = client.Execute(request);
            helper.HandleResponseStatusCodeBadRequest(response);
            test.Log(Status.Pass, "ostEnrollmentSearchAPINoClientID-Request Executed and Response validated succesfully");  
        }
            catch(Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
        
    }
}
