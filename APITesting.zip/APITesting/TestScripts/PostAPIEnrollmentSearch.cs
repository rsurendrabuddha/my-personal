﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APITesting.Config;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollmentSearch
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void PostAPIEnrollmentSearchEndPoint()
        {
            client = new RestClient(constants.postApiEnrollmentSearchURL);
            request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f" }
            });
            response = client.Execute(request);
            helper.HandleResponse(response);

        }

        [Test]
        public void WrongClientID()
        {
            client = new RestClient(constants.postApiEnrollmentSearchURL);
            request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "51ab2ddc5-ca6d-4572-9bb8-9a4624f7978f" }
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }


        [Test]
        public void NoClientID()
        {
            client = new RestClient(constants.postApiEnrollmentSearchURL);
            request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "" }
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }


        [Test]
        public void InvalidJSonFormat()
        {
            client = new RestClient(constants.postApiEnrollmentSearchURL);
            request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                "clientIdList" ["51ab2ddc5-ca6d-4572-9bb8-9a4624f7978f"]
            });

            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
    }
}
