﻿using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;
using APITesting;

namespace CMA.TestScripts
{
    public class EndToEndWorkFlow : ExtentReportSetup
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentReports extent;
        private ExtentTest test;

        [OneTimeSetUp]
        public void SetupReporting()
        {
            new ExtentReportSetup().Setup();
        }

        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test, Order(1)]
        public void PostAPIEnrollmentEndPoint()
        {
             //test = extent.CreateTest(TestContext.CurrentContext.Test.Name);
            test = new ExtentReportSetup().CreateTest("PostEnrollmentAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.postAPIEnrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");
                // Add JSON body to the request
                request.AddJsonBody(new
                {
                    //ClientId = randomGuidString,
                    displayName = "aadapp-ccm-platform-api-client-nonprod",
                    costCenter = "99999",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        allowedFromEmails = new[]
                        {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                    },
                    requireSms = false
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeCreated(response);
                test.Log(Status.Pass, "PostEnrollmentAPI-Request Executed and Response validated succesfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test, Order(2)]
        public void PostAPIEnrollmentConsumerAndDeleteEndPoint()
        {
            test = new ExtentReportSetup().CreateTest("PostEnrollmentConsumerAPI").Info("Test Started");
            try
            {

                client = new RestClient(constants.postApiEnrollmentConsumerURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postAPIEnrollmentConsumerEndPoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");

                Guid randomGuid = Guid.NewGuid();
                string randomGuidString = randomGuid.ToString();
                Console.WriteLine("Random GUID: " + randomGuidString);

                request.AddJsonBody(new
                {
                    displayName = "aadapp-ccm-platform-api-client-nonprod",
                    costCenter = "124587",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                  new
                  {
                      emailAddress = "ccmuksupport@investec.co.za",
                      contactPersonName = "ccm-uk-support"
                  }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        estimatedVolume = 1,
                        allowedFromEmails = new[]
                        {
                        new
                        {
                          displayName = "Hera Comms",
                          emailAddress = "noreply@investec.com"
                        }
                    }
                    },
                    requireSms = false,
                    //clientId = randomGuidString
                    clientId = "b22a241c-ed39-45e5-bbd8-780968a4e835"
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeNoContent(response);
                test.Log(Status.Pass, "PostEnrollmentConsumerAPI-Request Executed and response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test, Order(3)]
        public void PostAPIEnrollmentSearchEndPoint()
        {
            test = new ExtentReportSetup().CreateTest("PostEnrollmentSearchAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.postApiEnrollmentSearchURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postApiEnrollmentSearchEndPoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");
                request.AddJsonBody(new
                {
                    clientIdList = new[] { "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f" }
                });

                response = client.Execute(request);
                helper.HandleResponseStatusCodeOk(response);
                test.Log(Status.Pass, "PostEnrollmentSearchAPI-Request Executed and Response validated succesfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test, Order(4)]
        public void GetMethodAPIEnrollment()
        {
            test = new ExtentReportSetup().CreateTest("GetEnrollmentAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.getenrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.getapiEnrollmentEndpoint, Method.Get);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                response = client.Execute(request);
                helper.HandleResponseStatusCodeOk(response);
                test.Log(Status.Pass, "GetEnrollmentAPI Request Executed and Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }
        [Test, Order(5)]
        public void PutAPIEnrollmentEndPointPositiveWorkFlow()
        {
            test = new ExtentReportSetup().CreateTest("PutEnrollmentAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.putenrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.putApiEnrollmentEndpoint, Method.Put);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");

                request.AddJsonBody(new
                {
                    ClientId = constants.clientID,
                    displayName = constants.displayName,
                    costCenter = constants.costCentre,
                    businessUnit = constants.businessUnit,
                    jurisdiction = constants.jursidiction,
                    contactPersons = new[]
                {
                  new
                    {
                     emailAddress = constants.emailAddress,
                     contactPersonName = constants.contactPersonName
                    }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        allowedFromEmails = new[]
                        {
                       new
                        {
                          displayName = constants.enrollmentDisplayName,
                          emailAddress = constants.enrollmentEmailAddress
                        }
                    }
                    },
                    requireSms = false
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeNoContent(response);
                test.Log(Status.Pass, "PutEnrollmentAPI-Request Executed and got the Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }

        }
        
        [Test, Order(6)]
        public void DeleteAPIEnrollmentConsumer()
        {
            //Delete API Enrollment Consumer
            test = new ExtentReportSetup().CreateTest("DeleteEnrollmentConsumerAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.deleteApiEnrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");
                request.AddJsonBody(new
                {
                    clientIdList = new[] { "b22a241c-ed39-45e5-bbd8-780968a4e835" }
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeNoContent(response);
                test.Log(Status.Pass, "DeleteEnrollmentConsumerAPI-Request Executed and Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }
    
    [TearDown]
        public void TearDown()
        {
            new HelperClass().CleanupTestData();
            client.Dispose();
        }
        [OneTimeTearDown]

        public void TearDownReporting()
        {
            new ExtentReportSetup().TearDown();

        }
    }


}
