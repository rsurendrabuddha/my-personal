﻿using System.ComponentModel;
using APITesting.Config;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class DeleteAPIEnrollment
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void wrongClientID()
        {
            client = new RestClient(constants.deleteApiEnrollmentURL);
            request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "51ab-ca6d-4572-9bb8-9a4624f7978f" }
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [Test]
        public void NoClientID()
        {
            client = new RestClient(constants.deleteApiEnrollmentURL);
            request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "" }
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [Test]
        public void InvalidJsonFormat()
        {
            client = new RestClient(constants.deleteApiEnrollmentURL);
            request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                "clientIdList"["51ab2ddc5-ca6d-4572-9bb8-9a4624f7978f"]
            });
            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
    }
}


