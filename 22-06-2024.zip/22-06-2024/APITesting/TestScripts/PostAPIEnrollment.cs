﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollment
    {
        [Test]
        public async Task PostAPIEnrollmentEndPoint()
        {

            var client1 = new RestClient();
            var request1 = new RestRequest("https://login.microsoftonline.com/6d6a11bc-469a-48df-a548-d3f353ac1be8/oauth2/v2.0/token", Method.Post);

            request1.AddHeader("Cookie", "fpc=AttaWyulqRtKrGJC__irNLne9UZIAQAAAGlD-t0OAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd");
            request1.AddParameter("grant_type", "client_credentials");
            request1.AddParameter("client_secret", "qyF8Q~ZSUDH6OhQdZeWJOl-_7t-2pi2-GmB.abu.");
            request1.AddParameter("client_id", "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f");
            request1.AddParameter("scope", "api://aadapp-ocp-ccnc-global-cma-enrollment-api-nonprod.investec.io/.default");

            var response1 = await client1.ExecuteAsync(request1);

            JObject responseContent = JObject.Parse(response1.Content);

            // Retrieve the access token from the response
            string bearerToken = responseContent["access_token"].ToString();

            Console.WriteLine("Access Token: " + bearerToken);

            // Create RestClient instance with base URL
            var client = new RestClient("https://ca-cma-enrollment-api-dev-001.politeglacier-57b1a428.northeurope.azurecontainerapps.io");

            // Create request object
            var request = new RestRequest("/api/enrollment", Method.Post);

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            //Guid randomGuid = Guid.NewGuid();
            //string randomGuidString = randomGuid.ToString();
            //Console.WriteLine("Random GUID: " + randomGuidString);

            // Add JSON body to the request
            request.AddJsonBody(new
            {
                //ClientId = randomGuidString,
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "99999",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });


            // Execute the request
            RestResponse response = client.Execute(request);

            // Check if the request was successful
            if (response.IsSuccessful)
            {
                Console.WriteLine("Post request successful!");
                Console.WriteLine("Response:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Error occurred: " + response.ErrorMessage);
                Assert.Fail();
            }
        }
    }
}
