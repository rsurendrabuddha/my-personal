﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using RestSharp;

namespace APITesting
{
    public class HelperClass
    {
        public void HandleResponse(RestResponse response)
        {
            Console.WriteLine($"Response Status Code: {(int)response.StatusCode} {response.StatusCode}");

            if (response.IsSuccessful)
            {
                Console.WriteLine("Response Content:");
                Console.WriteLine(response.Content);  // differene
            }
            else
            {
                Console.WriteLine($"Request failed with status code: {response.StatusCode}");
                Assert.Fail($"Request failed with status code: {response.StatusCode}");
            }
        }
    }
}
