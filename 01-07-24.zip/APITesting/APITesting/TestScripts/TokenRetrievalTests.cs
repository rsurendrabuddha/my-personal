﻿using NUnit.Framework;
using RestSharp;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using APITesting.Config;

namespace APITesting.TestScripts
{
    public class TokenRetrieval
    {
        private Constants constants = new Constants();

        public async Task<string> GetBearerToken()
        {
            var client1 = new RestClient();
            var request1 = new RestRequest(constants.tokenURL, Method.Post);

            request1.AddHeader("Cookie", constants.cookie);
            request1.AddParameter("grant_type", constants.grantType);
            request1.AddParameter("client_secret", constants.clientSecret);
            request1.AddParameter("client_id", constants.clientId);
            request1.AddParameter("scope", constants.scope);

            var response1 = await client1.ExecuteAsync(request1);

            JObject responseContent = JObject.Parse(response1.Content);

            // Retrieve the access token from the response
            string bearerToken = responseContent["access_token"].ToString();

            Console.WriteLine("Access Token: " + bearerToken);

            return bearerToken;
        }
    }
}
