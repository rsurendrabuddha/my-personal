﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APITesting.Config
{
    public class Constants
    {
        //Enrollment URL
        public string getenrollmentURL = "https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io";
        public string postAPIEnrollmentURL = "https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io";
        public string putenrollmentURL = "https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io";
        public string postApiEnrollmentSearchURL = "https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io";
        public string postApiEnrollmentConsumerURL = "https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io";
        public string deleteApiEnrollmentURL = "https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io";

        // Enrollment Endpoints
        public string getapiEnrollmentEndpoint = "/api/enrollment";
        public string postApiEnrollmentEndpoint = "/api/enrollment";
        public string putApiEnrollmentEndpoint = "/api/enrollment";
        public string postApiEnrollmentSearchEndPoint = "/api/enrollment/search";
        public string postAPIEnrollmentConsumerEndPoint = "/api/enrollment/consumer";
        public string deleteApiEnrollmentEndPoint = "/api/enrollment/consumer";

        //Json Body Constants
        public string clientID = "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f";
        public string displayName = "aadapp-ccm-platform-api-client-nonprod";
        public string costCentre = "99299";
        public string businessUnit = "CCM Tech UK Offshore";
        public string jursidiction = "UK";
        public string emailAddress = "ccmuksupport@investec.co.za";
        public string contactPersonName = "ccm-uk-support";
        public string enrollmentDisplayName = "era Comms";
        public string enrollmentEmailAddress = "noreply@investec.com";

        // Token Constants
        public string tokenURL = "https://login.microsoftonline.com/6d6a11bc-469a-48df-a548-d3f353ac1be8/oauth2/v2.0/token";
        public string cookie = "fpc=AttaWyulqRtKrGJC__irNLne9UZIAQAAAGlD-t0OAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd";
        public string grantType = "client_credentials";
        public string clientSecret = "qyF8Q~ZSUDH6OhQdZeWJOl-_7t-2pi2-GmB.abu.";
        public string clientId = "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f";
        public string scope = "api://aadapp-ocp-ccnc-global-cma-enrollment-api-nonprod.investec.io/.default";
    }
}
