﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APITesting.Config;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollmentConsumer
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void PostAPIEnrollmentConsumerAndDeleteEndPoint()
        {
            client = new RestClient(constants.postApiEnrollmentConsumerURL);
            request = new RestRequest(constants.postAPIEnrollmentConsumerEndPoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            Guid randomGuid = Guid.NewGuid();
            string randomGuidString = randomGuid.ToString();
            Console.WriteLine("Random GUID: " + randomGuidString);

            request.AddJsonBody(new
            {
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "124587",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                  new
                  {
                      emailAddress = "ccmuksupport@investec.co.za",
                      contactPersonName = "ccm-uk-support"
                  }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    estimatedVolume = 1,
                    allowedFromEmails = new[]
                    {
                        new
                        {
                          displayName = "Hera Comms",
                          emailAddress = "noreply@investec.com"
                        }
                    }
                },
                requireSms = false,
                clientId = randomGuidString
            });
            response = client.Execute(request);
            helper.HandleResponse(response);


            // Delete API Enrollment Consumer
            client2 = new RestClient(constants.deleteApiEnrollmentURL);
            request2 = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            request2.AddHeader("Authorization", $"Bearer {bearerToken}");
            request2.AddHeader("ActionedBy", "Test");
            request2.AddJsonBody(new
            {
                clientIdList = new[] { randomGuidString }
            });
            response2 = client2.Execute(request2);
            helper.HandleResponse(response2);
        }


        [Test]
        public void InvalidJsonFormat()
        {
            client = new RestClient(constants.postApiEnrollmentConsumerURL);
            request = new RestRequest(constants.postAPIEnrollmentConsumerEndPoint, Method.Post);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            Guid randomGuid = Guid.NewGuid();
            string randomGuidString = randomGuid.ToString();
            Console.WriteLine("Random GUID: " + randomGuidString);

            request.AddJsonBody(new
            {
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "124587",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new
                {
                  new
                  {
                      emailAddress = "ccmuksupport@investec.co.za",
                      contactPersonName = "ccm-uk-support"
                  }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    estimatedVolume = 1,
                    allowedFromEmails = new
                    {
                        new
                        {
                          displayName = "Hera Comms",
                          emailAddress = "noreply@investec.com"
                        }
                    }
                },
                requireSms = false,
                clientId = randomGuidString
            });
            response = client.Execute(request);
            helper.HandleResponse(response);

        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
    }
}
