﻿using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;


namespace APITesting.TestScripts
{
    [TestFixture]
    public class DeleteAPIEnrollment
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentTest test;   
        private ExtentReports extent;

        [OneTimeSetUp]
        public void SetupReporting()
        {
            var htmlReporter = new ExtentHtmlReporter("C:\\Users\\Reports\\extent.html");
            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
        }


        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void wrongClientID()
        {
            test = extent.CreateTest("wrongclientID").Info("Test Started");
            try
            {
             client = new RestClient(constants.deleteApiEnrollmentURL);
            test.Log(Status.Pass, "Created a RestClient Object"); 
            
            request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            test.Log(Status.Pass, "Created a RestRequest Object");  
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            test.Log(Status.Pass, "Bearer Token added");   
            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "51ab-ca6d-4572-9bb8-9a4624f7978f" }
            });
            response = client.Execute(request);
            helper.HandleResponseStatusCodeNoContent(response);
            test.Log(Status.Pass, "DeleteEnrollmentConsumerAPI-WrongClientID-Request Executed and Response validated successfully"); 
        }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test]
        public void NoClientID()
        {
            test = extent.CreateTest("NoClientID").Info("Test Started");
            try
            {
            client = new RestClient(constants.deleteApiEnrollmentURL);
            test.Log(Status.Pass, "Created a RestClient Object");

            request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            test.Log(Status.Pass, "Created a RestRequest Object");

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            test.Log(Status.Pass, "Bearer Token added");

            request.AddHeader("ActionedBy", "Test");
            request.AddJsonBody(new
            {
                clientIdList = new[] { "" }
            });
            response = client.Execute(request);
            helper.HandleResponseStatusCodeInternalServerError(response);
            test.Log(Status.Pass, "DeleteEnrollmentConsumerAPI-NoClientID-Request Executed and Response validated successfully");  
        }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [Test]
        public void MissingActionByField()
        {
            test = extent.CreateTest("DeleteEnrollmentConsumerAPI-MissingActionByField").Info("Test Started");
            try
            {
                client = new RestClient(constants.deleteApiEnrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddJsonBody(new
                {
                    clientIdList = new[] { "51ab-ca6d-4572-9bb8-9a4624f7978f" }
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeBadRequest(response);
                test.Log(Status.Pass, "DeleteEnrollmentConsumerAPI-MissingActionByField Request Executed and Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

            [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
        [OneTimeTearDown]

        public void TearDownReporting()
        {
            extent.Flush();

        }
    }
}



