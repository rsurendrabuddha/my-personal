﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMA.TestScripts.Query_API
{
    internal class GetQueryDateRangeAPI
    {
    }
}
