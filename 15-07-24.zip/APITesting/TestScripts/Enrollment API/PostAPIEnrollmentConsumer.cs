﻿using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollmentConsumer

    {
        private string bearerToken;
        private RestClient client;
        private RestClient client2;
        private RestRequest request;
        private RestRequest request2;
        private RestResponse response;
        private RestResponse response2;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentReports extent;
        private ExtentTest test;

        [OneTimeSetUp]
        public void SetupReporting()
        {
            var htmlReporter = new ExtentHtmlReporter("C:\\Users\\New folder\\");
            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
        }

        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }

        [Test]
        public void PostAPIEnrollmentConsumerAndDeleteEndPoint()
        {
            test = extent.CreateTest("PostEnrollmentConsumerAPI").Info("Test Started");
            try
            {

                client = new RestClient(constants.postApiEnrollmentConsumerURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postAPIEnrollmentConsumerEndPoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");

                Guid randomGuid = Guid.NewGuid();
                string randomGuidString = randomGuid.ToString();
                Console.WriteLine("Random GUID: " + randomGuidString);

                request.AddJsonBody(new
                {
                    displayName = "aadapp-ccm-platform-api-client-nonprod",
                    costCenter = "124587",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                  new
                  {
                      emailAddress = "ccmuksupport@investec.co.za",
                      contactPersonName = "ccm-uk-support"
                  }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        estimatedVolume = 1,
                        allowedFromEmails = new[]
                        {
                        new
                        {
                          displayName = "Hera Comms",
                          emailAddress = "noreply@investec.com"
                        }
                    }
                    },
                    requireSms = false,
                    //clientId = randomGuidString
                    clientId = "b22a241c-ed39-45e5-bbd8-780968a4e835"
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeNoContent(response);
                test.Log(Status.Pass, "PostEnrollmentConsumerAPI-Request Executed and response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }

            ////Delete API Enrollment Consumer
            //test = extent.CreateTest("DeleteEnrollmentConsumerAPI").Info("Test Started");
            //try
            //{
            //    client2 = new RestClient(constants.deleteApiEnrollmentURL);
            //    test.Log(Status.Pass, "Created a RestClient Object");

            //    request2 = new RestRequest(constants.deleteApiEnrollmentEndPoint, Method.Delete);
            //    test.Log(Status.Pass, "Created a RestRequest Object");

            //    request2.AddHeader("Authorization", $"Bearer {bearerToken}");
            //    test.Log(Status.Pass, "Bearer Token added");

            //    request2.AddHeader("ActionedBy", "Test");
            //    request2.AddJsonBody(new
            //    {
            //        clientIdList = new[] { "b22a241c-ed39-45e5-bbd8-780968a4e835" }
            //    });
            //    response2 = client2.Execute(request2);
            //    helper.HandleResponseStatusCodeNoContent(response2);
            //    test.Log(Status.Pass, "DeleteEnrollmentConsumerAPI-Request Executed and Response validated successfully");
            //}
            //catch (Exception e)
            //{
            //    string errorMessage = e.Message;
            //    test.Log(Status.Fail, "Test Failed: " + errorMessage);
            //}
        }


        [Test]
        public void MissingActionByField()
        {
            test = extent.CreateTest("PostEnrollmentcosumerAPI-MissingActionByField").Info("Test Started");
            try
            {
                client = new RestClient(constants.postApiEnrollmentConsumerURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postAPIEnrollmentConsumerEndPoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                Guid randomGuid = Guid.NewGuid();
                string randomGuidString = randomGuid.ToString();
                Console.WriteLine("Random GUID: " + randomGuidString);

                request.AddJsonBody(new
                {
                    displayName = "aadapp-ccm-platform-api-client-nonprod",
                    costCenter = "124587",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                  new
                  {
                      emailAddress = "ccmuksupport@investec.co.za",
                      contactPersonName = "ccm-uk-support"
                  }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        estimatedVolume = 1,
                        allowedFromEmails = new[]
                        {
                        new
                        {
                          displayName = "Hera Comms",
                          emailAddress = "noreply@investec.com"
                        }
                    }
                    },
                    requireSms = false,
                    clientId = randomGuidString
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeBadRequest(response);
                test.Log(Status.Pass, "PostEnrollmentcosumerAPI-MissingActionByField-Request Executed and Response validated successfully");

            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }
        [Test]
        public void RemoveMandatoryFields()
        {
            test = extent.CreateTest("PostEnrollmentcosumerAPI-RemoveMandatoryFields").Info("Test Started");
            try
            {
                client = new RestClient(constants.postAPIEnrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.postApiEnrollmentEndpoint, Method.Post);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                request.AddHeader("ActionedBy", "Test");

                request.AddJsonBody(new
                {
                    ClientId = "51ab2cc5-cad-4572-97978f",
                    businessUnit = "CCM Tech UK Offshore",
                    jurisdiction = "UK",
                    contactPersons = new[]
                    {
                    new
                    {
                       emailAddress = "ccmuksupport@investec.co.za",
                       contactPersonName = "ccm-uk-support"
                    }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        allowedFromEmails = new[]
                        {
                       new
                       {
                          displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                    },
                    requireSms = false
                });
                response = client.Execute(request);
                helper.HandleResponseStatusCodeBadRequest(response);
                test.Log(Status.Pass, "PostEnrollmentcosumerAPI-RemoveMandatoryFields-Request Executed and Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }

        [OneTimeTearDown]

        public void TearDownReporting()
        {
            extent.Flush();

        }
    }

}
