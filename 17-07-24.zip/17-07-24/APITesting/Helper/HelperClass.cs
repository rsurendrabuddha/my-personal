﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using NUnit.Framework.Legacy;
using RestSharp;

namespace APITesting
{
    public class HelperClass
    {
        private RestClient restClient;
        public void HandleResponseStatusCodeOk(RestResponse response)
        {
            Console.WriteLine($"Response Status Code: {(int)response.StatusCode} {response.StatusCode}");

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                ClassicAssert.AreEqual(System.Net.HttpStatusCode.OK, response.StatusCode);
                Console.WriteLine("Response Content:");
                Console.WriteLine(response.Content);  
            }
            else
            {
                Console.WriteLine($"Request failed with status code: {response.StatusCode}");
                Assert.Fail($"Request failed with status code: {response.StatusCode}");
            }
        }
        public void HandleResponseStatusCodeNoContent(RestResponse response)
        {
            if (response.StatusCode== System.Net.HttpStatusCode.NoContent)
            {
                //string content = response.ResponseStatus.ToString();
                //string content1 = response.StatusDescription.ToString();
                ClassicAssert.AreEqual(System.Net.HttpStatusCode.NoContent, response.StatusCode);
                Console.WriteLine("Response Content:");
                Console.WriteLine(response.Content);  
            }
            else
            {
                Console.WriteLine($"Request failed with status code: {response.StatusCode}");
                Assert.Fail($"Request failed with status code: {response.StatusCode}");
            }

        }
        public void HandleResponseStatusCodeInternalServerError(RestResponse response)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                ClassicAssert.AreEqual(System.Net.HttpStatusCode.InternalServerError, response.StatusCode);
                Console.WriteLine("Response Content:");
                Console.WriteLine(response.Content);  
            }
            else
            {
                Console.WriteLine($"Request failed with status code: {response.StatusCode}");
                Assert.Fail($"Request failed with status code: {response.StatusCode}");
            }

        }
        public void HandleResponseStatusCodeCreated(RestResponse response)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.Created)
            {
                ClassicAssert.AreEqual(System.Net.HttpStatusCode.Created, response.StatusCode);
                Console.WriteLine("Response Content:");
                Console.WriteLine(response.Content);  
            }
            else
            {
                Console.WriteLine($"Request failed with status code: {response.StatusCode}");
                Assert.Fail($"Request failed with status code: {response.StatusCode}");
            }

        }
        public void HandleResponseStatusCodeBadRequest(RestResponse response)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                ClassicAssert.AreEqual(System.Net.HttpStatusCode.BadRequest, response.StatusCode);
                Console.WriteLine("Response Content:");
                Console.WriteLine(response.Content);  
            }
            else
            {
                Console.WriteLine($"Request failed with status code: {response.StatusCode}");
                Assert.Fail($"Request failed with status code: {response.StatusCode}");
            }

        }
        public void CleanupTestData()
        {
            // Example of deleting test data
            var client = new RestClient("https://ca-cma-enroll-api-nonprod-001.happysky-cff076f3.southafricanorth.azurecontainerapps.io");
            var request = new RestRequest("/subscriptions/81ba0926-298f-4bea-a676-88e1174803cd/resourceGroups/rg-globalcma-nonprod-001/providers/Microsoft.App/containerapps/ca-cma-enroll-api-nonprod-001", Method.Delete);
            request.AddUrlSegment("id", "/subscriptions/81ba0926-298f-4bea-a676-88e1174803cd/resourceGroups/rg-globalcma-nonprod-001/providers/Microsoft.App/containerapps/ca-cma-enroll-api-nonprod-001"); // Replace with actual resource ID

            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Handle successful cleanup
            }
            else
            {
                // Handle cleanup failure
            }
        }
    }


}

