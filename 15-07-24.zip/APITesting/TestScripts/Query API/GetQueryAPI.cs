﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APITesting;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;

namespace CMA.TestScripts.Query_API
{
    [TestFixture]
    public class GetQueryAPI : ExtentReportSetup
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentReports extent;
        private ExtentTest test;


        [OneTimeSetUp]
        public void SetupReporting()
        {
            new ExtentReportSetup().Setup();
        }
        [SetUp]
        public void setup()
        {
            //test = extent.CreateTest(TestContext.CurrentContext.Test.Name);
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }
        [Test]
        public async Task GetMethodAPIEnrollment()
        {
            string keyVaultUrl = "https://dev.azure.com/investec/ocp/_library?itemType=VariableGroups&view=VariableGroupView&variableGroupId=2764&path=Automation%20testing%20-CMA-Enviroment%20URL";
            string secretName = "getenrollmentURL";

            // Retrieve secret from Azure Key Vault
            AzureKeyVaultHelper keyVaultHelper = new AzureKeyVaultHelper(keyVaultUrl);
            string secretValue = await keyVaultHelper.GetSecretAsync(secretName);
            Console.WriteLine($"Retrieved secret: {secretValue}");
            test = new ExtentReportSetup().CreateTest("GetMethodEnrollmentAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.getenrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.getapiEnrollmentEndpoint, Method.Get);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                response = client.Execute(request);
                helper.HandleResponseStatusCodeOk(response);
                test.Log(Status.Pass, "GetEnrollmentAPI Request Executed and Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
        [OneTimeTearDown]
        public void TearDownReporting()
        {
            new ExtentReportSetup().TearDown();

        }
    }
}
