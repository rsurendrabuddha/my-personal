﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;

public class ExtentReportSetup
{
    protected static  ExtentReports extent;
    protected  ExtentTest test;

    [OneTimeSetUp]
    public void Setup()
    {
        var htmlReporter = new ExtentHtmlReporter("C:\\Users\\Reports\\");
        extent = new ExtentReports();
        extent.AttachReporter(htmlReporter);
    }

    public ExtentTest CreateTest(String name)
    {
        test = extent.CreateTest(name);
        return test;
    }


    [OneTimeTearDown]
    public void TearDown()
    {
        extent.Flush();
    }
}
