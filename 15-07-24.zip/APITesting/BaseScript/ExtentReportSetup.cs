﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;

public class ExtentReportSetup
{
    protected static  ExtentReports extent;
    protected  ExtentTest test;

   
    public void Setup()
    {
        var htmlReporter = new ExtentHtmlReporter("C:\\Users\\Reports\\ExtentReport.html");
        extent = new ExtentReports();
        extent.AttachReporter(htmlReporter);
    }

    public ExtentTest CreateTest(String name)
    {
        test = extent.CreateTest(name);
        return test;
    }


    
    public void TearDown()
    {
        extent.Flush();
    }
}
