﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APITesting.Config
{
    public class Constants
    {
        public string enrollmentURL = "https://ca-cma-enroll-api-nonprod-001.redfield-aacfd160.northeurope.azurecontainerapps.io";
        public string apiEnrollmentEndpoint = "/api/enrollment";

        // Token Constants
        public string tokenURL = "https://login.microsoftonline.com/6d6a11bc-469a-48df-a548-d3f353ac1be8/oauth2/v2.0/token";
        public string cookie = "fpc=AttaWyulqRtKrGJC__irNLne9UZIAQAAAGlD-t0OAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd";
        public string grantType = "client_credentials";
        public string clientSecret = "qyF8Q~ZSUDH6OhQdZeWJOl-_7t-2pi2-GmB.abu.";
        public string clientId = "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f";
        public string scope = "api://aadapp-ocp-ccnc-global-cma-enrollment-api-nonprod.investec.io/.default";
    }
}
