﻿using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;
using AventStack.ExtentReports.Reporter;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class GetAPIEnrollment
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentReports extent;
        private ExtentTest test;


        [OneTimeSetUp]
        public void SetupReporting()
        {
            var htmlReporter = new ExtentHtmlReporter("C:\\Users\\Reports\\extent.html");
            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
        }

        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();
            Console.WriteLine("Token obtained: " + bearerToken);
        }
        [Test]
        public void GetMethodAPIEnrollment()
        {
            test = extent.CreateTest("GetEnrollmentAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.getenrollmentURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.getapiEnrollmentEndpoint, Method.Get);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");

                response = client.Execute(request);
                helper.HandleResponseStatusCodeOk(response);
                test.Log(Status.Pass, "GetEnrollmentAPI Request Executed and Response validated successfully");
            }
            catch(Exception e)
            {
                string errorMessage = e.Message;
               test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
        [OneTimeTearDown]

        public void TearDownReporting()
        {
            extent.Flush();

        }
    }
}





