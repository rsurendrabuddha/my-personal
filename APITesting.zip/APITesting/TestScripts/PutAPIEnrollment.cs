﻿using APITesting.Config;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PutAPIEnrollment
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();

        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken();

        }

        [Test]
        public void PutAPIEnrollmentEndPointPositiveWorkFlow()
        {

                client = new RestClient(constants.putenrollmentURL);
                request = new RestRequest(constants.putApiEnrollmentEndpoint, Method.Put);
                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                request.AddHeader("ActionedBy", "Test");

                request.AddJsonBody(new
                {
                    ClientId = constants.clientID,
                    displayName = constants.displayName,
                    costCenter = constants.costCentre,
                    businessUnit = constants.businessUnit,
                    jurisdiction = constants.jursidiction,
                    contactPersons = new[]
                {
                  new
                    {
                     emailAddress = constants.emailAddress,
                     contactPersonName = constants.contactPersonName
                    }
                },
                    requireEmail = true,
                    emailEnrollment = new
                    {
                        allowedFromEmails = new[]
                        {
                       new
                        {
                          displayName = constants.enrollmentDisplayName,
                          emailAddress = constants.enrollmentEmailAddress
                        }
                    }
                        },
                    requireSms = false
                });
                response = client.Execute(request);
                helper.HandleResponse(response);
        }

        [Test]
        public void MissingMandatoryField()
        {
            client = new RestClient(constants.putenrollmentURL);
            request = new RestRequest(constants.putApiEnrollmentEndpoint, Method.Put);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            request.AddJsonBody(new
            {
                //ClientId = randomGuidString,
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                {
                  new
                  {
                   emailAddress = "ccmuksupport@investec.co.za",
                   contactPersonName = "ccm-uk-support"
                  }
                },
                requireEmail = true,
                emailEnrollment = new
               {
                    allowedFromEmails = new[]
                 {
                     new
                    {
                     displayName = "era Comms",
                     emailAddress = "noreply@investec.com"
                    } 
                 }
              },
                requireSms = false
            });

            response = client.Execute(request);
            helper.HandleResponse(response);
        }


        [Test]
        public void InvalidJSONFormat()
        {
            client = new RestClient(constants.putenrollmentURL);
            request = new RestRequest(constants.putApiEnrollmentEndpoint, Method.Put);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            request.AddJsonBody(new
            {
                //ClientId = randomGuidString,
                displayName = "aad-nonprod",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
               {
                  
                  {
                   emailAddress = "ccmuksupport@investec.co.za",
                   contactPersonName = "ccm-uk-support"
                  }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                {
          
                    {
                     displayName = "era Comms",
                     emailAddress = "noreply.com"
                    }
                 }
                },
                requireSms = false
            });

            response = client.Execute(request);
            helper.HandleResponse(response);
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
    }
}
