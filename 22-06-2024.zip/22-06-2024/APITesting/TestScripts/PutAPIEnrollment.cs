﻿using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PutAPIEnrollment
    {
        [Test]
        public async Task PutAPIEnrollmentEndPoint()
        {

            var client1 = new RestClient();
            var request1 = new RestRequest("https://login.microsoftonline.com/6d6a11bc-469a-48df-a548-d3f353ac1be8/oauth2/v2.0/token", Method.Post);

            request1.AddHeader("Cookie", "fpc=AttaWyulqRtKrGJC__irNLne9UZIAQAAAGlD-t0OAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd");
            request1.AddParameter("grant_type", "client_credentials");
            request1.AddParameter("client_secret", "qyF8Q~ZSUDH6OhQdZeWJOl-_7t-2pi2-GmB.abu.");
            request1.AddParameter("client_id", "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f");
            request1.AddParameter("scope", "api://aadapp-ocp-ccnc-global-cma-enrollment-api-nonprod.investec.io/.default");

            var response1 = await client1.ExecuteAsync(request1);

            JObject responseContent = JObject.Parse(response1.Content);

            // Retrieve the access token from the response
            string bearerToken = responseContent["access_token"].ToString();

            Console.WriteLine("Access Token: " + bearerToken);

            // Create RestClient instance with base URL
            var client = new RestClient("https://ca-cma-enrollment-api-dev-001.politeglacier-57b1a428.northeurope.azurecontainerapps.io");

            // Create request object
            var request = new RestRequest("/api/enrollment", Method.Put);

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            // Add JSON body to the request
            request.AddJsonBody(new
            {
                ClientId = "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f",
                displayName = "aadapp-ccm-platform-api-client-nonprod",
                costCenter = "99299",
                businessUnit = "CCM Tech UK Offshore",
                jurisdiction = "UK",
                contactPersons = new[]
                                {
                  new
                  {
                     emailAddress = "ccmuksupport@investec.co.za",
                     contactPersonName = "ccm-uk-support"
                  }
                },
                requireEmail = true,
                emailEnrollment = new
                {
                    allowedFromEmails = new[]
                    {
                       new
                       {
                         displayName = "era Comms",
                          emailAddress = "noreply@investec.com"
                       }
                    }
                },
                requireSms = false
            });
            // add log for payload 


            // Execute the request
            RestResponse response = client.Execute(request);

            // Check if the request was successful
            if (response.IsSuccessful)
            {
                Console.WriteLine("Put request successful!");
                Console.WriteLine("Response:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Error occurred: " + response.ErrorMessage);
                Assert.Fail();
            }
        }
    }
}
