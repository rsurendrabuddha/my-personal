﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;

namespace APITesting.TestScripts
{
    [TestFixture]
    public class PostAPIEnrollmentSearch
    {
        [Test]
        public async Task PostAPIEnrollmentSearchEndPoint()
        {

            var client1 = new RestClient();
            var request1 = new RestRequest("https://login.microsoftonline.com/6d6a11bc-469a-48df-a548-d3f353ac1be8/oauth2/v2.0/token", Method.Post);

            request1.AddHeader("Cookie", "fpc=AttaWyulqRtKrGJC__irNLne9UZIAQAAAGlD-t0OAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd");
            request1.AddParameter("grant_type", "client_credentials");
            request1.AddParameter("client_secret", "qyF8Q~ZSUDH6OhQdZeWJOl-_7t-2pi2-GmB.abu.");
            request1.AddParameter("client_id", "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f");
            request1.AddParameter("scope", "api://aadapp-ocp-ccnc-global-cma-enrollment-api-nonprod.investec.io/.default");

            var response1 = await client1.ExecuteAsync(request1);

            JObject responseContent = JObject.Parse(response1.Content);

            // Retrieve the access token from the response
            string bearerToken = responseContent["access_token"].ToString();

            Console.WriteLine("Access Token: " + bearerToken);

            // Create RestClient instance with base URL
            var client = new RestClient("https://ca-cma-enroll-api-nonprod-001.redfield-aacfd160.northeurope.azurecontainerapps.io");

            // Create request object
            var request = new RestRequest("/api/enrollment/search", Method.Post);

            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("ActionedBy", "Test");

            // Add JSON body to the request
            request.AddJsonBody(new
            {
                clientIdList = new[] { "51ab2cc5-ca6d-4572-9bb8-9a4624f7978f" }
            });

         



            // Execute the request
            RestResponse response = client.Execute(request);

            // Check if the request was successful
            if (response.IsSuccessful)
            {
                Console.WriteLine("Post enrollment Search request successful!");
                Console.WriteLine("Response:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Error occurred: " + response.ErrorMessage);
                Assert.Fail();
            }

        }

    }
}
