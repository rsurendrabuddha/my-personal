﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APITesting;
using APITesting.Config;
using AventStack.ExtentReports;
using NUnit.Framework;
using RestSharp;

namespace CMA.TestScripts.Query_API
{
    [TestFixture]
    public class GetQueryAPI : ExtentReportSetup
    {
        private string bearerToken;
        private RestClient client;
        private RestRequest request;
        private RestResponse response;
        private HelperClass helper = new HelperClass();
        private Constants constants = new Constants();
        private TokenHelper tokenHelper = new TokenHelper();
        private ExtentReports extent;
        private ExtentTest test;


        [OneTimeSetUp]
        public void SetupReporting()
        {
            new ExtentReportSetup().Setup();
        }
        [SetUp]
        public void setup()
        {
            bearerToken = tokenHelper.GetToken("Query");
            Console.WriteLine("Token obtained: " + bearerToken);
        }
        [Test]
        public void GetQueryAPI_PositiveWorkFlow()
        {
            test = new ExtentReportSetup().CreateTest("GetQueryAPI").Info("Test Started");
            try
            {
                client = new RestClient(constants.getQueryAPIURL);
                test.Log(Status.Pass, "Created a RestClient Object");

                request = new RestRequest(constants.GetQueryAPIEndpoint, Method.Get);
                test.Log(Status.Pass, "Created a RestRequest Object");

                request.AddHeader("Authorization", $"Bearer {bearerToken}");
                test.Log(Status.Pass, "Bearer Token added");
                request.AddHeader("id", constants.QueryTrackingID);

                response = client.Execute(request);
                helper.HandleResponseStatusCodeOk(response);
                test.Log(Status.Pass, "GetEnrollmentAPI Request Executed and Response validated successfully");
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                test.Log(Status.Fail, "Test Failed: " + errorMessage);
            }
        }

        [TearDown]
        public void TearDown()
        {
            client.Dispose();
        }
        [OneTimeTearDown]
        public void TearDownReporting()
        {
            new ExtentReportSetup().TearDown();

        }
    }
}
